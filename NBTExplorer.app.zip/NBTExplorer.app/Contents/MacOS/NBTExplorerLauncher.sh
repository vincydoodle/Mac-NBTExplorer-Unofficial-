#!/bin/bash
/usr/local/bin/wine /Applications/NBTExplorer.app/Contents/Resources/NBTExplorer.exe
